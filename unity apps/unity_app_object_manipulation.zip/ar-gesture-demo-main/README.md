# ar-gesture-demo

## Getting started

1. Install Unity 2019.4.20f1.
