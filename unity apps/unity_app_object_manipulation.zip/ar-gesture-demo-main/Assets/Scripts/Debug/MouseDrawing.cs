﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseDrawing : MonoBehaviour
{
    public LineRenderer lineRenderer;
    public float distanceToPoint = 0.02f;
    private DollarRecognizer recognizer = new DollarRecognizer();
    private Vector3 lastPosition;
    private List<Vector2> points2d = new List<Vector2>();
    private List<Vector3> points = new List<Vector3>();
    private GestureRecognizer recognizer2 = new GestureRecognizer();

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            Vector3 newPosition = ray.origin + distanceToPoint * ray.direction;
            float distance = Vector3.Distance(newPosition, lastPosition);
            if (distance > 0.001f)
            {
                AddPointToLineRenderer(ray.origin + distanceToPoint * ray.direction);
                lastPosition = newPosition;
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            //DollarRecognizer.Result result = recognizer.Recognize(points2d, false);
            //Debug.Log("Result: " + result.name + " Score: " + result.score + " Time: " + result.time);
            DollarRecognizer.Result result2 = recognizer2.Recognize3DGesture(points, -Vector3.up, -Vector3.forward);
            Debug.Log("Result: " + result2.name);

            ClearLineRenderer();
            lastPosition = -9999f * Vector3.one;
        }
    }

    void AddPointToLineRenderer(Vector3 point)
    {
        lineRenderer.SetPosition(lineRenderer.positionCount++, point);
        points2d.Add(new Vector2(point.x, -point.y));
        points.Add(point);
    }

    void ClearLineRenderer()
    {
        lineRenderer.positionCount = 0;
        points2d.Clear();
        points.Clear();
    }
}
