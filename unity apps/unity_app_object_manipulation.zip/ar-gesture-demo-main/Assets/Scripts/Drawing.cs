﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Google.XR.ARCoreExtensions.Samples.CloudAnchors;

public class PositionsList : SyncListStruct<Vector3> { }

public class Drawing : NetworkBehaviour
{
    // Start is called before the first frame update
    PositionsList positions = new PositionsList();

    LineRenderer lineRenderer;
    private CloudAnchorsExampleController _cloudAnchorsExampleController;

    public void Awake()
    {
        _cloudAnchorsExampleController =
            GameObject.Find("CloudAnchorsExampleController")
            .GetComponent<CloudAnchorsExampleController>();
    }

    void Start()
    {
        positions.Callback = PositionsChanged;
    }

    public void SetParentToWorldOrigin()
    {
        transform.SetParent(_cloudAnchorsExampleController.WorldOrigin);
    }

    // Update is called once per frame
    void Update()
    {
        transform.SetParent(_cloudAnchorsExampleController.WorldOrigin, false);
    }

    void PositionsChanged(PositionsList.Operation op, int itemIndex)
    {
        SyncLineRenderer();
    }

    public void AddPosition(Vector3 newPosition)
    {
        positions.Add(newPosition);
        SyncLineRenderer();
    }

    void SyncLineRenderer()
    {
        Vector3[] positionsArray = new Vector3[positions.Count];
        positions.CopyTo(positionsArray, 0);
        GetLineRenderer().positionCount = positionsArray.Length;
        GetLineRenderer().SetPositions(positionsArray);
    }

    LineRenderer GetLineRenderer()
    {
        if (lineRenderer == null)
        {
            lineRenderer = GetComponent<LineRenderer>();
        }
        return lineRenderer;
    }
}
