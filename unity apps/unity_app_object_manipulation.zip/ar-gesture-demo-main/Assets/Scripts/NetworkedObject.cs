﻿using Google.XR.ARCoreExtensions.Samples.CloudAnchors;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetworkedObject : MonoBehaviour
{

    private CloudAnchorsExampleController _cloudAnchorsExampleController;

    public void Awake()
    {
        _cloudAnchorsExampleController =
            GameObject.Find("CloudAnchorsExampleController")
            .GetComponent<CloudAnchorsExampleController>();
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.SetParent(_cloudAnchorsExampleController.WorldOrigin, false);
    }

    public void SetParentToWorldOrigin()
    {
        transform.SetParent(_cloudAnchorsExampleController.WorldOrigin);
    }

}
