﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Google.XR.ARCoreExtensions.Samples.CloudAnchors;

public class DrawingManager : MonoBehaviour
{

    public CloudAnchorsExampleController cloudAnchorController;

    public GameObject drawingPrefab;
    public float distanceToDrawing = 0.5f;

    private GameObject localplayer;
    private LocalPlayerController localplayercontroller;
    private bool currentlyDrawingLine = false;
    private GestureRecognizer recognizer = new GestureRecognizer();
    private List<Vector3> points = new List<Vector3>();
    private Vector3 lastPosition;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.touchCount >= 1 && cloudAnchorController.CanPlaceStars())
        {
            Touch touch = Input.GetTouch(0);
            Ray ray = Camera.main.ScreenPointToRay(touch.position);
            Vector3 targetPosition = ray.origin + distanceToDrawing * ray.direction;
            if (touch.phase == TouchPhase.Began)
            {
                CreateDrawing(targetPosition);
                currentlyDrawingLine = true;
            }
            else
            {
                UpdateLastDrawing(targetPosition);
                currentlyDrawingLine = true;
            }
        }
        else
        {
            if (currentlyDrawingLine)
            {
                CompleteLastDrawing();
                currentlyDrawingLine = false;
            }
        }
    }

    void CreateDrawing(Vector3 position)
    {
        points.Add(position);
        Pose pose = ToWorldOriginPose(new Pose(position, Quaternion.identity));
        FindPlayer().GetComponent<LocalPlayerController>().CmdSpawnDrawing(pose.position, pose.rotation);
        FindPlayer().GetComponent<LocalPlayerController>().CmdUpdateLastDrawing(pose.position);
        lastPosition = position;
    }

    void UpdateLastDrawing(Vector3 newPosition)
    {
        if (Vector3.Distance(lastPosition, newPosition) > 0.01f)
        {
            points.Add(newPosition);
            FindPlayer().GetComponent<LocalPlayerController>().CmdUpdateLastDrawing(
                ToWorldOriginPosition(newPosition));
            lastPosition = newPosition;
        }
    }

    void CompleteLastDrawing()
    {
        DollarRecognizer.Result result = recognizer.Recognize3DGesture(
            points,
            -Camera.main.transform.up,
            -Camera.main.transform.forward,
            false);
        Vector3 averagePosition = GetAveragePosition();
        Debug.Log("Detected gesture: " + result.name);
        switch (result.name)
        {
            case "circle":
                FindPlayerController().CmdSpawnSphere(
                    ToWorldOriginPosition(averagePosition),
                    Quaternion.identity);
                DeleteLastDrawing();
                break;
            case "rectangle":
                FindPlayerController().CmdSpawnCube(
                    ToWorldOriginPosition(averagePosition),
                    Quaternion.identity);
                DeleteLastDrawing();
                break;
            case "star":
                FindPlayerController().CmdSpawnStar(
                    ToWorldOriginPosition(averagePosition),
                    Quaternion.identity);
                DeleteLastDrawing();
                break;
            default:
                // TODO: Update edge collider.
                break;
        };
        points.Clear();
    }

    void DeleteLastDrawing()
    {
        FindPlayerController().CmdDeleteLastDrawing();
    }

    Vector3 GetAveragePosition()
    {
        Vector3 averagePosition = Vector3.zero;
        foreach (Vector3 vec in points)
        {
            averagePosition += vec;
        }
        return averagePosition / points.Count;
    }

    Pose ToWorldOriginPose(Pose pose)
    {
        return cloudAnchorController.ToWorldOriginPose(pose);
    }

    Vector3 ToWorldOriginPosition(Vector3 position)
    {
        return ToWorldOriginPose(new Pose(position, Quaternion.identity)).position;
    }

    GameObject FindPlayer()
    {
        return (localplayer != null) ?
            localplayer :
            (localplayer = GameObject.Find("LocalPlayer"));
    }

    LocalPlayerController FindPlayerController()
    {
        return (localplayercontroller != null) ?
            localplayercontroller :
            (localplayercontroller = FindPlayer().GetComponent<LocalPlayerController>());
    }
}
