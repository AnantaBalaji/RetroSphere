﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Factorization;

public class GestureRecognizer
{
    public DollarRecognizer dollarRecognizer = new DollarRecognizer();

    public GestureRecognizer()
    {

    }

    /// <summary>
    /// Recognize a gesture from a set of 3D points.
    /// </summary>
    /// <param name="points"></param>
    /// <returns></returns>
    public DollarRecognizer.Result Recognize3DGesture(List<Vector3> points, Vector3 upGuess, Vector3 forwardGuess, bool useProtractor = false)
    {
        if (points.Count == 0)
        {
            return dollarRecognizer.Recognize(new List<Vector2>(), useProtractor);
        }
        List<Vector2> points_2d = ProjectToVector2(points, upGuess, forwardGuess);
        return dollarRecognizer.Recognize(points_2d, useProtractor);
    }

    /// <summary>
    /// Projects a set of points in R3 to R2 along its principal axis.
    /// </summary>
    /// <param name="points"></param>
    /// <param name="center">Center the matrix before projection.</param>
    /// <returns></returns>
    public List<Vector2> ProjectToVector2(List<Vector3> points, Vector3 upGuess, Vector3 forwardGuess, bool center = true, bool logProjection=false)
    {
        Matrix<float> pointsMat = PointsListToMatrix(points).Transpose();
        if (center)
        {
            Vector<float> rowSums = pointsMat.RowSums() / points.Count;
            pointsMat.MapIndexedInplace((i, j, x) => x - rowSums[i]);
        }
        Svd<float> svd = pointsMat.Svd();


        // (2, 3) matrix.
        Matrix<float> projectionMatrix = svd.U.SubMatrix(0, 3, 0, 2).Transpose();
        if (Mathf.Abs(DotProduct(upGuess, projectionMatrix.Row(0))) > Mathf.Abs(DotProduct(upGuess, projectionMatrix.Row(1))))
        {
            projectionMatrix = Matrix<float>.Build.Dense(2, 3, (i, j) => projectionMatrix[i == 1 ? 0 : 1, j]);
        }
        if (DotProduct(upGuess, projectionMatrix.Row(1)) < 0)
        {
            projectionMatrix.MapIndexedInplace((i, j, x) => i == 1 ? -x : x);
        }
        Vector<float> forward = CrossProduct(projectionMatrix.Row(0), projectionMatrix.Row(1));
        if (DotProduct(forwardGuess, forward) < 0)
        {
            projectionMatrix.MapIndexedInplace((i, j, x) => i == 0 ? -x : x);
        }
        if (logProjection)
        {
            Debug.Log("Projection:\n" + projectionMatrix.ToMatrixString());
        }

        // (2, N) = (2, 3) * (3, N)
        Matrix<float> projected = projectionMatrix * pointsMat;
        List<Vector2> projectedPoints = new List<Vector2>();
        for (int i = 0; i < projected.ColumnCount; i++)
        {
            projectedPoints.Add(new Vector2(projected[0, i], projected[1, i]));
        }
        return projectedPoints;
    }

    /// <summary>
    /// Converts a of N Vector3 points to an (N, 3) matrix.
    /// </summary>
    /// <param name="points"></param>
    /// <returns></returns>
    public Matrix<float> PointsListToMatrix(List<Vector3> points)
    {
        Matrix<float> mat = Matrix<float>.Build.Dense(points.Count, 3);
        for (int i = 0; i < points.Count; i++)
        {
            mat[i, 0] = points[i].x;
            mat[i, 1] = points[i].y;
            mat[i, 2] = points[i].z;
        }
        return mat;
    }

    private static float DotProduct(Vector3 vec1, Vector<float> vec2)
    {
        return vec1.x * vec2[0] + vec1.y * vec2[1] + vec1.z * vec2[2];
    }

    private static Vector<float> CrossProduct(Vector<float> vec1, Vector<float> vec2)
    {
        Vector3 c = Vector3.Cross(
            new Vector3(vec1[0], vec1[1], vec1[2]),
            new Vector3(vec2[0], vec2[1], vec2[2]));
        return Vector<float>.Build.DenseOfArray(new float[] { c.x, c.y, c.z });
    }
}
