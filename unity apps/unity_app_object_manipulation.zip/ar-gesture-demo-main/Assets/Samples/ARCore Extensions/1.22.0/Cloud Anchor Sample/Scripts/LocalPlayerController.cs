//-----------------------------------------------------------------------
// <copyright file="LocalPlayerController.cs" company="Google LLC">
//
// Copyright 2019 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// </copyright>
//-----------------------------------------------------------------------

namespace Google.XR.ARCoreExtensions.Samples.CloudAnchors
{
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;
    using UnityEngine.Networking;
    using UnityEngine.XR.ARFoundation;

    /// <summary>
    /// Local player controller. Handles the spawning of the networked Game Objects.
    /// </summary>
#pragma warning disable 618
    public class LocalPlayerController : NetworkBehaviour
#pragma warning restore 618
    {
        /// <summary>
        /// The Star model that will represent networked objects in the scene.
        /// </summary>
        public GameObject StarPrefab;

        /// <summary>
        /// The Anchor model that will represent the anchor in the scene.
        /// </summary>
        public GameObject AnchorPrefab;

        public GameObject DrawingPrefab;
        public GameObject SpherePrefab;
        public GameObject CubePrefab;

        [System.NonSerialized]
        public List<GameObject> drawings = new List<GameObject>();

        /// <summary>
        /// The Unity OnStartLocalPlayer() method.
        /// </summary>
        public override void OnStartLocalPlayer()
        {
            base.OnStartLocalPlayer();

            // A Name is provided to the Game Object so it can be found by other Scripts, since this
            // is instantiated as a prefab in the scene.
            gameObject.name = "LocalPlayer";
        }

        /// <summary>
        /// Will spawn the origin anchor and host the Cloud Anchor. Must be called by the host.
        /// </summary>
        /// <param name="anchor">The AR Anchor to be hosted.</param>
        public void SpawnAnchor(ARAnchor anchor)
        {
            // Instantiate Anchor model at the hit pose.
            var anchorObject = Instantiate(AnchorPrefab, Vector3.zero, Quaternion.identity);

            // Anchor must be hosted in the device.
            anchorObject.GetComponent<AnchorController>().HostAnchor(anchor);

            // Host can spawn directly without using a Command because the server is running in this
            // instance.
#pragma warning disable 618
            NetworkServer.Spawn(anchorObject);
#pragma warning restore 618
        }

        /// <summary>
        /// A command run on the server that will spawn the Star prefab in all clients.
        /// </summary>
        /// <param name="position">Position of the object to be instantiated.</param>
        /// <param name="rotation">Rotation of the object to be instantiated.</param>
#pragma warning disable 618
        [Command]
#pragma warning restore 618
        public void CmdSpawnStar(Vector3 position, Quaternion rotation)
        {
            // Instantiate Star model at the hit pose.
            var starObject = Instantiate(StarPrefab, position, rotation);

            starObject.GetComponent<StarController>().SetParentToWorldOrigin();

            // Spawn the object in all clients.
#pragma warning disable 618
            NetworkServer.Spawn(starObject);
#pragma warning restore 618
        }

        [Command]
        public void CmdSpawnDrawing(Vector3 position, Quaternion rotation)
        {
            GameObject drawing = Instantiate(DrawingPrefab, position, rotation);
            drawing.GetComponent<Drawing>().SetParentToWorldOrigin();
            NetworkServer.Spawn(drawing);
            drawings.Add(drawing);
        }

        [Command]
        public void CmdUpdateLastDrawing(Vector3 newPosition)
        {
            if (drawings.Count == 0) { return; }
            GameObject lastDrawing = drawings[drawings.Count - 1];
            lastDrawing.GetComponent<Drawing>().AddPosition(newPosition);
        }

        [Command]
        public void CmdDeleteLastDrawing()
        {
            if (drawings.Count == 0) { return; }
            GameObject lastDrawing = drawings[drawings.Count - 1];
            Destroy(lastDrawing);
            NetworkServer.Destroy(lastDrawing);
        }

        [Command]
        public void CmdSpawnSphere(Vector3 position, Quaternion rotation)
        {
            GameObject sphere = Instantiate(SpherePrefab, position, rotation);
            sphere.GetComponent<NetworkedObject>().SetParentToWorldOrigin();
            NetworkServer.Spawn(sphere);
        }

        [Command]
        public void CmdSpawnCube(Vector3 position, Quaternion rotation)
        {
            GameObject cube = Instantiate(CubePrefab, position, rotation);
            cube.GetComponent<NetworkedObject>().SetParentToWorldOrigin();
            NetworkServer.Spawn(cube);
        }
    }
}
